

function [P,C,UN,time,test] = LCSLSF(Data,target,alpha,ns,p,maxK,MB)


start=tic;

P=[];
C=[];
UN=[];
pc=[];
DAG1=[];
[aMB,test,time] = OLaMB(Data,target,alpha,ns,p,maxK);
                    
                           m=length(aMB)+1;
                           data2=[];
                            if m>=2
                                for k=1:m-1
                                    data_col3=Data(:,aMB(k));
                                     data2=[data2,data_col3];
                                end
                                data_col=Data(:,target);
                                data2= [data2,data_col];
                                numFeatures3 = size(data2,2);
                             
                                if numFeatures3>1
                                    ns3=max(data2);
                                    all_PC=cell(1,p);
                                    all_sepset=cell(1,p);
                                    all_MB=cell(1,p);

                                    % step 1�� establish seketon

                                    PP=zeros(p,p);
                                    for i=1:p
                                         [PC,test] = HITONPC_G2(data2,i,alpha,ns3,m,maxK);
                                          PP(i,PC)=1;
                                    end
                                    skeleton=PP;

                                    % step 2�� orient V-structures

                                    for i=1:p
                                        all_PC{i}=find(skeleton(i,:)==1);
                                    end

                                    DAG=skeleton;
                                    pdag=skeleton;
                                    G=skeleton;

                                    for i=1:p
                                        A=i;
                                        PCA=all_PC{A};
                                        disp("A")
                                        disp(A)
                                        for j=1:length(PCA)
                                            B=PCA(j);
                                            disp("PCA")
                                            disp(PCA)
                                            disp(B)
                                            PCB=all_PC{B};
                                            for k=1:length(PCB)
                                                disp("PCB")
                                                disp(PCB)
                                                C=PCB(k);
                                                disp(C)
                                                if ismember(C,all_PC{A})||C==A
                                                    continue;
                                                end

                                                CanPC=all_PC{C};
                                                CanPC2=all_PC{A};
                                                cutSetSize = 0;

                                                break_flag=0;
                                                if length(CanPC) >= length(CanPC2)
                                                   while length(CanPC) >= cutSetSize &&cutSetSize<=maxK
                                                    disp(111111)
                                                    SS = subsets1(CanPC, cutSetSize);  


                                                        for si=1:length(SS)
                                                        Z = SS{si};

                                                        test=test+1;
                                                        pval=my_g2_test(C,A,Z,data2,ns3,alpha);

                                                        if pval>alpha

                                                            all_sepset{A}{C}=Z;

                                                            if ~ismember(B,Z)
                                                                test=test+1;
                                                                 pval=my_g2_test(C,A,myunion(Z,B),data2,ns3,alpha);

                                                                 if isnan(pval)||pval<=alpha

                                                                    pdag(A,B) = -1; pdag(C,B) = -1; pdag(B,A) = 0; pdag(B,C) = 0;
                                                                    G(A,B) = 1;     G(C,B) = 1;     G(B,A) = 0;    G(B,C) = 0;



                                                                 end
                                                            end

                                                            break_flag=1;
                                                            break;
                                                        end
                                                    end


                                                    if break_flag
                                                        break;
                                                    end
                                                    cutSetSize = cutSetSize + 1;
                                                end
                                                else
                                                    while length(CanPC) >= cutSetSize &&cutSetSize<=maxK

                                                    SS2 = subsets1(CanPC2, cutSetSize);

                                                         for si=1:length(SS2)
                                                        Z2 = SS2{si};

                                                        test=test+1;
                                                        pval=my_g2_test(A,C,Z2,Data,ns,alpha);

                                                        if pval>alpha

                                                            all_sepset{C}{A}=Z2;

                                                            if ~ismember(B,Z2)
                                                                test=test+1;
                                                                 pval=my_g2_test(A,C,myunion(Z2,B),Data,ns,alpha);

                                                                 if isnan(pval)||pval<=alpha

                                                                    pdag(A,B) = -1; pdag(C,B) = -1; pdag(B,A) = 0; pdag(B,C) = 0;
                                                                    G(A,B) = 1;     G(C,B) = 1;     G(B,A) = 0;    G(B,C) = 0;



                                                                 end
                                                            end

                                                            break_flag=1;
                                                            break;
                                                        end
                                                    end



                                                    if break_flag
                                                        break;
                                                    end
                                                    cutSetSize = cutSetSize + 1;
                                                end


                                                end    
                                            end
                                        end
                                        [DAG1,pdag,G]=meeks(DAG1,pdag,G,p);
                                    end
                                    
                                    
                                  else
                                   DAG1=zeros(numFeatures3); 
                                end
                            else
                                 data_col=Data(:,target);
                                 data2= [data2,data_col];
                                 DAG1=zeros(1);
                            end

[~,trueP,trueC,truePC] = STA(DAG1);
 numFeatures3 = size(data2,2);
   for i=1:length(trueP{numFeatures3})
       P=[P,MB(aMB(trueP{numFeatures3}(i)))]; 
   end

    for i=1:length(trueC{numFeatures3})
       C=[C,MB(aMB(trueC{numFeatures3}(i)))];
    end



time=toc(start);
