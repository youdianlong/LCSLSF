function [aMB,test,time] = OLaMB(Data,target,alpha,ns,p,maxK)

start=tic;

numFeatures = size(Data,2);
dep=sparse(1,numFeatures-1);
uncpc=[];
cpc=[];
cpc2=[];
cpc3=[];
cpc4=[];
cpc_tmp=[];
cpc_tmp1=[];
sp=[];
pc=[];
aMB=[];
if (nargin == 3)
      [s,p]=size(Data);
      maxK=3;
end 
test=0;
PC=[]; 
cpc2=[];
pc_tmp=[];
dep=zeros(1,p);
sepset=cell(1,p);
spouse = cell(1,p);
dep_sp=zeros(p,p);


if (nargin == 3)
   ns=max(Data);
   [~,p]=size(Data);
   maxK=3;
end
NonTPC=[];
for i=1:p
    if i~=target
        stop=0;
        test=test+1;
        [pval, dep(i)]=my_g2_test(i,target,[],Data,ns,alpha);

        if isnan(pval)
            CI=1;      
        else
            if pval<=alpha
                CI=0;
            else
                CI=1;
            end
        end
        
        if CI==1
              NonTPC=[NonTPC,i];
%            continue;
        end
        if CI==0
            stop=1;
             cpc=[cpc,i];
            
        end
        [~,var_index]=sort(dep(cpc),'descend');
      
        
        if stop                      
            for n=1:length(cpc)
                X=cpc(var_index(n));

                pc=[pc X];
                pc_length=length(pc);
                pc_tmp=pc;
                last_break_flag=0;
                for j=pc_length:-1:1
                    Y = pc(j);
                    CanPC=mysetdiff(pc_tmp, Y);

                    cutSetSize = 1;             
                    other_break_flag=0;
                    while length(CanPC) >= cutSetSize && cutSetSize<=maxK
                        SS = subsets1(CanPC, cutSetSize);    
                        for si=1:length(SS)
                            Z = SS{si};

                            if X~=Y       
                                if isempty(find(Z==X, 1))
                                    continue;
                                end
                            end                 

                            test=test+1;
                            [pval]=my_g2_test(Y,target,Z,Data,ns,alpha);     
                            if isnan(pval)
                                CI=0;
                            else
                                if pval<=alpha
                                    CI=0;
                                else
                                    CI=1;
                                end
                            end
                            if CI==1 
                                pc_tmp=CanPC;
                                sepset{Y}=Z;
                                NonTPC=myunion(NonTPC,Y);                                 
                                
                                if X==Y
                                    last_break_flag=1;
                                end     

                                other_break_flag=1;    
                                break;
                            end 
                        end

                        if last_break_flag||other_break_flag
                            break;
                        end

                        cutSetSize = cutSetSize + 1;
                    end

                    if last_break_flag
                        break;
                    end
                  
                end
                pc=pc_tmp;
            end      
        end
%          

        
    end 
     for k = 1:length(pc)
                Y = pc(k);
                break_flag=0;
                for j=1:length(NonTPC)
                    X = NonTPC(j);
                    S =  myunion(sepset{1,X}, Y);      
                    test = test +1;
                    [pval]=my_g2_test(target,X,S,Data,ns,alpha);     
                    if isnan(pval)        
                        CI=0;
                    else
                        if pval<=alpha
                            CI=0;
                        else
                            CI=1;
                        end
                    end

                    if(CI==0)    
            
                        spouse{1,Y} = myunion ( spouse{1,Y} ,X ); 
                        m=Y;
                spousety = spouse{1,m};

                if (~isempty(spousety))
                    Y=m;
                    for n=1:length(spousety)
                        X = spousety(n);

                        testset = mysetdiff( myunion(pc,spouse{1,Y}),X );

                        test=test+1;
                        [pval]=my_g2_test(X,target,testset,Data,ns,alpha);       

                        if isnan(pval)      
                            CI=0;
                        else
                            if pval<=alpha
                                CI=0;
                            else
                                CI=1;
                            end
                        end

                        if CI==1 
                   
                            spouse{1,Y}=mysetdiff(spouse{1,Y},X );
                           
                        end
                    end

                end

                    end
                end
            end

end


mb=myunion(pc,cell2mat(spouse));
aMB=unique(mb);

time=toc(start);


  
